import pytest

from app import crear_app


@pytest.fixture
def cliente(tmp_path):
    app = crear_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    return app.test_client()


def agregar(cliente, **datos):
    base = {"descripcion": "Almuerzo", "monto": "12.50", "categoria": "Comida", "fecha": "2026-03-10"}
    base.update(datos)
    return cliente.post("/gastos", data=base, follow_redirects=True)


def test_agregar_y_ver_total(cliente):
    agregar(cliente)
    agregar(cliente, descripcion="Bus", monto="2.50", categoria="Transporte")
    html = cliente.get("/?mes=2026-03").get_data(as_text=True)
    assert "15.00" in html
    assert "Bus" in html


def test_filtra_por_mes(cliente):
    agregar(cliente, descripcion="Marzo")
    agregar(cliente, descripcion="Abril", fecha="2026-04-02")
    html = cliente.get("/?mes=2026-04").get_data(as_text=True)
    assert "Abril" in html and "Marzo" not in html


def test_rechaza_monto_negativo(cliente):
    r = agregar(cliente, monto="-5")
    assert "monto mayor a cero" in r.get_data(as_text=True)


def test_rechaza_categoria_desconocida(cliente):
    r = agregar(cliente, categoria="Inventada")
    assert "categoría" in r.get_data(as_text=True)


def test_exportar_csv(cliente):
    agregar(cliente)
    r = cliente.get("/exportar?mes=2026-03")
    assert r.mimetype == "text/csv"
    assert "2026-03-10,Almuerzo,Comida,12.50" in r.get_data(as_text=True)


def test_eliminar(cliente):
    agregar(cliente)
    cliente.post("/gastos/1/eliminar", data={"mes": "2026-03"})
    assert "No hay gastos" in cliente.get("/?mes=2026-03").get_data(as_text=True)
