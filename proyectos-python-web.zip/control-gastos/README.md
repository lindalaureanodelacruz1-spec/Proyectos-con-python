# Control de gastos

Aplicación web para registrar gastos personales, verlos por mes y entender en qué se va el dinero. Hecha con **Flask**, **SQLite** y **Chart.js**.

## Funcionalidades

- Registro de gastos con descripción, monto, categoría y fecha.
- Filtro por mes y total mensual.
- Gráfico de dona con el reparto por categoría.
- Exportación de los gastos del mes a CSV (se abre en Excel).
- Validación en el servidor: montos mayores a cero, fechas válidas y categorías permitidas.
- La moneda se configura con la variable de entorno `MONEDA` (por defecto `S/`).

## Tecnologías

Python 3 · Flask · SQLite · Jinja2 · Chart.js · HTML/CSS · pytest

## Cómo ejecutarlo

```bash
python -m venv .venv
source .venv/bin/activate      # En Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Abre http://127.0.0.1:5000 en tu navegador.

## Pruebas

```bash
pytest
```

## Ideas para mejorarlo

- Presupuesto mensual por categoría con alertas al superarlo.
- Registro de ingresos además de gastos.
- Gráfico de evolución de los últimos 12 meses.
