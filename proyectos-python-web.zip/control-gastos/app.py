"""Control de gastos personales con Flask, SQLite y Chart.js."""
import csv
import io
import os
import sqlite3
from datetime import date

from flask import Flask, Response, flash, g, redirect, render_template, request, url_for

MONEDA = os.environ.get("MONEDA", "S/")
CATEGORIAS = ["Comida", "Transporte", "Vivienda", "Servicios", "Salud", "Ocio", "Educación", "Otros"]


def crear_app(config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "cambia-esta-clave"),
        DATABASE=os.path.join(app.instance_path, "gastos.db"),
    )
    if config:
        app.config.update(config)
    os.makedirs(app.instance_path, exist_ok=True)

    def get_db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def cerrar_db(_exc):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    with app.app_context():
        get_db().execute(
            """CREATE TABLE IF NOT EXISTS gastos (
                   id          INTEGER PRIMARY KEY AUTOINCREMENT,
                   descripcion TEXT NOT NULL,
                   monto       REAL NOT NULL CHECK (monto > 0),
                   categoria   TEXT NOT NULL,
                   fecha       TEXT NOT NULL
               )"""
        )
        get_db().commit()

    @app.template_filter("dinero")
    def dinero(valor):
        return f"{MONEDA} {valor:,.2f}"

    def mes_actual():
        mes = request.args.get("mes", "")
        try:
            anio, m = map(int, mes.split("-"))
            date(anio, m, 1)
            return f"{anio:04d}-{m:02d}"
        except ValueError:
            return date.today().strftime("%Y-%m")

    def gastos_del_mes(mes):
        return get_db().execute(
            "SELECT * FROM gastos WHERE substr(fecha, 1, 7) = ? ORDER BY fecha DESC, id DESC",
            (mes,),
        ).fetchall()

    @app.get("/")
    def inicio():
        mes = mes_actual()
        gastos = gastos_del_mes(mes)
        por_categoria = get_db().execute(
            """SELECT categoria, SUM(monto) AS total FROM gastos
               WHERE substr(fecha, 1, 7) = ? GROUP BY categoria ORDER BY total DESC""",
            (mes,),
        ).fetchall()
        total = sum(g_["monto"] for g_ in gastos)
        return render_template(
            "index.html",
            mes=mes,
            gastos=gastos,
            total=total,
            categorias=CATEGORIAS,
            grafico={
                "etiquetas": [f["categoria"] for f in por_categoria],
                "valores": [round(f["total"], 2) for f in por_categoria],
            },
            por_categoria=por_categoria,
            hoy=date.today().isoformat(),
        )

    @app.post("/gastos")
    def agregar():
        descripcion = request.form.get("descripcion", "").strip()
        categoria = request.form.get("categoria", "")
        fecha = request.form.get("fecha", "")
        try:
            monto = round(float(request.form.get("monto", "")), 2)
            date.fromisoformat(fecha)
        except ValueError:
            flash("Revisa el monto y la fecha.", "error")
            return redirect(url_for("inicio"))

        if not descripcion or monto <= 0 or categoria not in CATEGORIAS:
            flash("Completa la descripción, un monto mayor a cero y una categoría.", "error")
            return redirect(url_for("inicio"))

        db = get_db()
        db.execute(
            "INSERT INTO gastos (descripcion, monto, categoria, fecha) VALUES (?, ?, ?, ?)",
            (descripcion, monto, categoria, fecha),
        )
        db.commit()
        flash(f"Gasto agregado: {descripcion}.", "ok")
        return redirect(url_for("inicio", mes=fecha[:7]))

    @app.post("/gastos/<int:gasto_id>/eliminar")
    def eliminar(gasto_id):
        db = get_db()
        db.execute("DELETE FROM gastos WHERE id = ?", (gasto_id,))
        db.commit()
        flash("Gasto eliminado.", "ok")
        return redirect(url_for("inicio", mes=request.form.get("mes")))

    @app.get("/exportar")
    def exportar():
        mes = mes_actual()
        salida = io.StringIO()
        escritor = csv.writer(salida)
        escritor.writerow(["fecha", "descripcion", "categoria", "monto"])
        for fila in gastos_del_mes(mes):
            escritor.writerow([fila["fecha"], fila["descripcion"], fila["categoria"], f"{fila['monto']:.2f}"])
        return Response(
            salida.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename=gastos-{mes}.csv"},
        )

    return app


app = crear_app()

if __name__ == "__main__":
    app.run(debug=True)
