# Cómo subir cada proyecto a GitHub

Repite esto para cada carpeta (cada proyecto debe ser un repositorio separado).

1. En GitHub, crea un repositorio nuevo **vacío** (sin README) con el nombre de la carpeta, por ejemplo `acortador-enlaces`.
2. En tu computadora:

```bash
cd acortador-enlaces
git init
git add .
git commit -m "Primera versión del acortador de enlaces"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/acortador-enlaces.git
git push -u origin main
```

## Consejos para que destaquen

- Agrega una captura de pantalla al README (guárdala en una carpeta `docs/` y enlázala con `![Captura](docs/captura.png)`).
- Haz varios commits pequeños al ir agregando mejoras, en vez de uno solo enorme: así se ve tu proceso.
- Implementa al menos una de las "Ideas para mejorarlo" de cada README: así el proyecto tendrá algo tuyo que podrás explicar en una entrevista.
- Escribe una descripción corta y agrega etiquetas (topics) como `python`, `flask`, `sqlite`.
