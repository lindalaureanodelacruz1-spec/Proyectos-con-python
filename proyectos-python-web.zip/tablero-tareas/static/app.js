const ESTADOS = ["pendiente", "en_curso", "hecho"];
const NOMBRES_PRIORIDAD = { baja: "Baja", media: "Media", alta: "Alta" };
const plantilla = document.getElementById("plantilla-tarjeta");
const cajaError = document.getElementById("error");
let tareas = [];

async function api(ruta, opciones = {}) {
  const respuesta = await fetch(ruta, {
    headers: { "Content-Type": "application/json" },
    ...opciones,
  });
  if (!respuesta.ok) {
    const cuerpo = await respuesta.json().catch(() => ({}));
    throw new Error(cuerpo.error || `Error ${respuesta.status}`);
  }
  return respuesta.status === 204 ? null : respuesta.json();
}

function mostrarError(mensaje) {
  cajaError.textContent = mensaje;
  cajaError.hidden = !mensaje;
}

function pintar() {
  document.querySelectorAll(".columna").forEach((columna) => {
    const estado = columna.dataset.estado;
    const lista = columna.querySelector("ul");
    const propias = tareas.filter((t) => t.estado === estado);
    lista.replaceChildren(...propias.map(crearTarjeta));
    columna.querySelector(".contador").textContent = propias.length;
  });
}

function crearTarjeta(tarea) {
  const nodo = plantilla.content.firstElementChild.cloneNode(true);
  nodo.dataset.id = tarea.id;
  nodo.querySelector(".texto").textContent = tarea.titulo;
  const etiqueta = nodo.querySelector(".prioridad");
  etiqueta.textContent = NOMBRES_PRIORIDAD[tarea.prioridad];
  etiqueta.dataset.nivel = tarea.prioridad;

  const indice = ESTADOS.indexOf(tarea.estado);
  nodo.querySelector('[data-dir="-1"]').disabled = indice === 0;
  nodo.querySelector('[data-dir="1"]').disabled = indice === ESTADOS.length - 1;

  nodo.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text/plain", tarea.id);
    nodo.classList.add("arrastrando");
  });
  nodo.addEventListener("dragend", () => nodo.classList.remove("arrastrando"));
  nodo.querySelectorAll(".mover").forEach((boton) =>
    boton.addEventListener("click", () => mover(tarea.id, ESTADOS[indice + Number(boton.dataset.dir)]))
  );
  nodo.querySelector(".borrar").addEventListener("click", () => borrar(tarea.id));
  return nodo;
}

async function cargar() {
  try {
    tareas = await api("/api/tareas");
    pintar();
  } catch (e) {
    mostrarError(e.message);
  }
}

async function mover(id, estado) {
  try {
    const actualizada = await api(`/api/tareas/${id}`, { method: "PATCH", body: JSON.stringify({ estado }) });
    tareas = tareas.map((t) => (t.id === actualizada.id ? actualizada : t));
    pintar();
    mostrarError("");
  } catch (e) {
    mostrarError(e.message);
  }
}

async function borrar(id) {
  try {
    await api(`/api/tareas/${id}`, { method: "DELETE" });
    tareas = tareas.filter((t) => t.id !== id);
    pintar();
  } catch (e) {
    mostrarError(e.message);
  }
}

document.getElementById("nueva").addEventListener("submit", async (e) => {
  e.preventDefault();
  const campo = document.getElementById("titulo");
  try {
    const nueva = await api("/api/tareas", {
      method: "POST",
      body: JSON.stringify({ titulo: campo.value, prioridad: document.getElementById("prioridad").value }),
    });
    tareas.push(nueva);
    pintar();
    campo.value = "";
    mostrarError("");
  } catch (err) {
    mostrarError(err.message);
  }
});

document.querySelectorAll(".columna").forEach((columna) => {
  columna.addEventListener("dragover", (e) => {
    e.preventDefault();
    columna.classList.add("encima");
  });
  columna.addEventListener("dragleave", () => columna.classList.remove("encima"));
  columna.addEventListener("drop", (e) => {
    e.preventDefault();
    columna.classList.remove("encima");
    const id = Number(e.dataTransfer.getData("text/plain"));
    const tarea = tareas.find((t) => t.id === id);
    if (tarea && tarea.estado !== columna.dataset.estado) mover(id, columna.dataset.estado);
  });
});

cargar();
