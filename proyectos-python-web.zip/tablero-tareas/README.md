# Tablero de tareas (Kanban)

Tablero estilo Kanban con tres columnas (Pendiente, En curso, Hecho). El backend es una **API REST en Flask** y el frontend está hecho en **JavaScript puro**, sin frameworks, con arrastrar y soltar.

## Funcionalidades

- Crear tareas con prioridad (baja, media, alta).
- Moverlas entre columnas arrastrándolas o con los botones ‹ ›, que también funcionan con teclado.
- Borrar tareas.
- Errores de la API mostrados en pantalla.

## API

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/tareas` | Lista todas las tareas |
| POST | `/api/tareas` | Crea una tarea. Cuerpo: `{"titulo": "...", "prioridad": "media"}` |
| PATCH | `/api/tareas/<id>` | Cambia `titulo`, `estado` o `prioridad` |
| DELETE | `/api/tareas/<id>` | Borra una tarea |

Ejemplo con curl:

```bash
curl -X POST http://127.0.0.1:5000/api/tareas \
  -H "Content-Type: application/json" \
  -d '{"titulo": "Subir el proyecto a GitHub", "prioridad": "alta"}'
```

## Tecnologías

Python 3 · Flask · SQLite · JavaScript (Fetch API, Drag and Drop) · HTML/CSS · pytest

## Cómo ejecutarlo

```bash
python -m venv .venv
source .venv/bin/activate      # En Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Abre http://127.0.0.1:5000 en tu navegador.

## Pruebas

```bash
pytest
```

## Ideas para mejorarlo

- Editar el título haciendo doble clic en la tarjeta.
- Ordenar tarjetas dentro de una misma columna.
- Fechas límite con aviso de tareas vencidas.
