"""Tablero de tareas tipo Kanban: API REST en Flask + frontend en JavaScript."""
import os
import sqlite3

from flask import Flask, abort, g, jsonify, render_template, request

ESTADOS = ("pendiente", "en_curso", "hecho")
PRIORIDADES = ("baja", "media", "alta")


def crear_app(config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(DATABASE=os.path.join(app.instance_path, "tareas.db"))
    if config:
        app.config.update(config)
    os.makedirs(app.instance_path, exist_ok=True)

    def get_db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def cerrar_db(_exc):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    with app.app_context():
        get_db().execute(
            """CREATE TABLE IF NOT EXISTS tareas (
                   id        INTEGER PRIMARY KEY AUTOINCREMENT,
                   titulo    TEXT NOT NULL,
                   estado    TEXT NOT NULL DEFAULT 'pendiente',
                   prioridad TEXT NOT NULL DEFAULT 'media',
                   creada    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
               )"""
        )
        get_db().commit()

    def a_dict(fila):
        return {k: fila[k] for k in fila.keys()}

    def obtener(tarea_id):
        fila = get_db().execute("SELECT * FROM tareas WHERE id = ?", (tarea_id,)).fetchone()
        if fila is None:
            abort(404, description="La tarea no existe.")
        return fila

    def error(mensaje, codigo=400):
        return jsonify({"error": mensaje}), codigo

    @app.get("/")
    def inicio():
        return render_template("index.html")

    @app.get("/api/tareas")
    def listar():
        filas = get_db().execute("SELECT * FROM tareas ORDER BY id").fetchall()
        return jsonify([a_dict(f) for f in filas])

    @app.post("/api/tareas")
    def crear():
        datos = request.get_json(silent=True) or {}
        titulo = str(datos.get("titulo", "")).strip()
        prioridad = datos.get("prioridad", "media")
        if not titulo or len(titulo) > 120:
            return error("El título es obligatorio y debe tener máximo 120 caracteres.")
        if prioridad not in PRIORIDADES:
            return error(f"La prioridad debe ser una de: {', '.join(PRIORIDADES)}.")
        db = get_db()
        cursor = db.execute("INSERT INTO tareas (titulo, prioridad) VALUES (?, ?)", (titulo, prioridad))
        db.commit()
        return jsonify(a_dict(obtener(cursor.lastrowid))), 201

    @app.patch("/api/tareas/<int:tarea_id>")
    def actualizar(tarea_id):
        obtener(tarea_id)
        datos = request.get_json(silent=True) or {}
        cambios = {}
        if "titulo" in datos:
            titulo = str(datos["titulo"]).strip()
            if not titulo or len(titulo) > 120:
                return error("El título es obligatorio y debe tener máximo 120 caracteres.")
            cambios["titulo"] = titulo
        if "estado" in datos:
            if datos["estado"] not in ESTADOS:
                return error(f"El estado debe ser uno de: {', '.join(ESTADOS)}.")
            cambios["estado"] = datos["estado"]
        if "prioridad" in datos:
            if datos["prioridad"] not in PRIORIDADES:
                return error(f"La prioridad debe ser una de: {', '.join(PRIORIDADES)}.")
            cambios["prioridad"] = datos["prioridad"]
        if not cambios:
            return error("No enviaste ningún campo para actualizar.")

        columnas = ", ".join(f"{c} = ?" for c in cambios)  # nombres validados arriba
        db = get_db()
        db.execute(f"UPDATE tareas SET {columnas} WHERE id = ?", (*cambios.values(), tarea_id))
        db.commit()
        return jsonify(a_dict(obtener(tarea_id)))

    @app.delete("/api/tareas/<int:tarea_id>")
    def borrar(tarea_id):
        obtener(tarea_id)
        db = get_db()
        db.execute("DELETE FROM tareas WHERE id = ?", (tarea_id,))
        db.commit()
        return "", 204

    @app.errorhandler(404)
    def no_encontrado(e):
        if request.path.startswith("/api/"):
            return error(e.description, 404)
        return e

    return app


app = crear_app()

if __name__ == "__main__":
    app.run(debug=True)
