import pytest

from app import crear_app


@pytest.fixture
def cliente(tmp_path):
    app = crear_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    return app.test_client()


def test_crear_y_listar(cliente):
    r = cliente.post("/api/tareas", json={"titulo": "Escribir README", "prioridad": "alta"})
    assert r.status_code == 201
    assert r.get_json()["estado"] == "pendiente"
    assert len(cliente.get("/api/tareas").get_json()) == 1


def test_titulo_obligatorio(cliente):
    r = cliente.post("/api/tareas", json={"titulo": "   "})
    assert r.status_code == 400
    assert "título" in r.get_json()["error"]


def test_mover_de_estado(cliente):
    tarea = cliente.post("/api/tareas", json={"titulo": "Probar API"}).get_json()
    r = cliente.patch(f"/api/tareas/{tarea['id']}", json={"estado": "hecho"})
    assert r.get_json()["estado"] == "hecho"


def test_estado_invalido(cliente):
    tarea = cliente.post("/api/tareas", json={"titulo": "X"}).get_json()
    r = cliente.patch(f"/api/tareas/{tarea['id']}", json={"estado": "volando"})
    assert r.status_code == 400


def test_borrar_y_404(cliente):
    tarea = cliente.post("/api/tareas", json={"titulo": "Temporal"}).get_json()
    assert cliente.delete(f"/api/tareas/{tarea['id']}").status_code == 204
    r = cliente.patch(f"/api/tareas/{tarea['id']}", json={"estado": "hecho"})
    assert r.status_code == 404
    assert r.get_json()["error"] == "La tarea no existe."
