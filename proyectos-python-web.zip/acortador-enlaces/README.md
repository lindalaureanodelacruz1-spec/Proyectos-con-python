# Acortador de enlaces

Aplicación web hecha con **Flask** y **SQLite** que convierte direcciones largas en enlaces cortos y cuenta cuántas veces se visita cada uno.

## Funcionalidades

- Genera códigos aleatorios y seguros con el módulo `secrets`.
- Permite elegir un alias personalizado (por ejemplo `/mi-portafolio`) y valida que no esté repetido ni sea una ruta reservada.
- Cuenta las visitas de cada enlace.
- Botón para copiar el enlace al portapapeles.
- Página 404 propia y mensajes de error claros.

## Tecnologías

Python 3 · Flask · SQLite · HTML/CSS · JavaScript · pytest

## Estructura

```
acortador-enlaces/
├── app.py            # Rutas, validación y acceso a la base de datos
├── templates/        # Plantillas Jinja2
├── static/style.css  # Estilos
└── tests/            # Pruebas automáticas con pytest
```

## Cómo ejecutarlo

```bash
python -m venv .venv
source .venv/bin/activate      # En Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Abre http://127.0.0.1:5000 en tu navegador.

## Pruebas

```bash
pytest
```

## Ideas para mejorarlo

- Agregar usuarios con inicio de sesión para que cada uno vea solo sus enlaces.
- Generar un código QR para cada enlace.
- Registrar la fecha de cada visita y mostrar un gráfico.
