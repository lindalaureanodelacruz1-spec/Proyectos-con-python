"""Acortador de enlaces con Flask y SQLite."""
import os
import re
import secrets
import sqlite3
import string
from urllib.parse import urlparse

from flask import Flask, abort, flash, g, redirect, render_template, request, url_for

ALFABETO = string.ascii_letters + string.digits
ALIAS_VALIDO = re.compile(r"^[A-Za-z0-9_-]{3,30}$")
RESERVADOS = {"acortar", "eliminar", "static"}


def crear_app(config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "cambia-esta-clave"),
        DATABASE=os.path.join(app.instance_path, "enlaces.db"),
    )
    if config:
        app.config.update(config)
    os.makedirs(app.instance_path, exist_ok=True)

    def get_db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def cerrar_db(_exc):
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    with app.app_context():
        get_db().execute(
            """CREATE TABLE IF NOT EXISTS enlaces (
                   codigo  TEXT PRIMARY KEY,
                   url     TEXT NOT NULL,
                   visitas INTEGER NOT NULL DEFAULT 0,
                   creado  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
               )"""
        )
        get_db().commit()

    def url_valida(url):
        partes = urlparse(url)
        return partes.scheme in ("http", "https") and bool(partes.netloc)

    def codigo_nuevo(db, largo=6):
        while True:
            codigo = "".join(secrets.choice(ALFABETO) for _ in range(largo))
            if not db.execute("SELECT 1 FROM enlaces WHERE codigo = ?", (codigo,)).fetchone():
                return codigo

    @app.get("/")
    def inicio():
        enlaces = get_db().execute(
            "SELECT * FROM enlaces ORDER BY creado DESC, rowid DESC LIMIT 50"
        ).fetchall()
        return render_template("index.html", enlaces=enlaces)

    @app.post("/acortar")
    def acortar():
        url = request.form.get("url", "").strip()
        alias = request.form.get("alias", "").strip()
        db = get_db()

        if not url_valida(url):
            flash("Escribe una dirección completa que empiece con http:// o https://", "error")
            return redirect(url_for("inicio"))

        if alias:
            if not ALIAS_VALIDO.match(alias) or alias.lower() in RESERVADOS:
                flash("El alias debe tener de 3 a 30 letras, números, guiones o guiones bajos.", "error")
                return redirect(url_for("inicio"))
            if db.execute("SELECT 1 FROM enlaces WHERE codigo = ?", (alias,)).fetchone():
                flash(f"El alias «{alias}» ya está en uso. Prueba con otro.", "error")
                return redirect(url_for("inicio"))
            codigo = alias
        else:
            codigo = codigo_nuevo(db)

        db.execute("INSERT INTO enlaces (codigo, url) VALUES (?, ?)", (codigo, url))
        db.commit()
        flash(url_for("redirigir", codigo=codigo, _external=True), "creado")
        return redirect(url_for("inicio"))

    @app.post("/eliminar/<codigo>")
    def eliminar(codigo):
        db = get_db()
        db.execute("DELETE FROM enlaces WHERE codigo = ?", (codigo,))
        db.commit()
        flash("Enlace eliminado.", "info")
        return redirect(url_for("inicio"))

    @app.get("/<codigo>")
    def redirigir(codigo):
        db = get_db()
        fila = db.execute("SELECT url FROM enlaces WHERE codigo = ?", (codigo,)).fetchone()
        if fila is None:
            abort(404)
        db.execute("UPDATE enlaces SET visitas = visitas + 1 WHERE codigo = ?", (codigo,))
        db.commit()
        return redirect(fila["url"], code=302)

    @app.errorhandler(404)
    def no_encontrado(_e):
        return render_template("404.html"), 404

    return app


app = crear_app()

if __name__ == "__main__":
    app.run(debug=True)
