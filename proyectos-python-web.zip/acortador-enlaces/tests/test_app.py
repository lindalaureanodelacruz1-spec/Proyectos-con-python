import pytest

from app import crear_app


@pytest.fixture
def cliente(tmp_path):
    app = crear_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db")})
    return app.test_client()


def test_inicio_vacio(cliente):
    r = cliente.get("/")
    assert r.status_code == 200
    assert "Aún no tienes enlaces" in r.get_data(as_text=True)


def test_crear_y_redirigir_con_alias(cliente):
    cliente.post("/acortar", data={"url": "https://github.com", "alias": "github"})
    r = cliente.get("/github")
    assert r.status_code == 302
    assert r.headers["Location"] == "https://github.com"


def test_cuenta_visitas(cliente):
    cliente.post("/acortar", data={"url": "https://python.org", "alias": "python"})
    cliente.get("/python")
    cliente.get("/python")
    html = cliente.get("/").get_data(as_text=True)
    assert ">2<" in html


def test_rechaza_url_invalida(cliente):
    r = cliente.post("/acortar", data={"url": "no-es-una-url"}, follow_redirects=True)
    assert "Escribe una dirección completa" in r.get_data(as_text=True)


def test_rechaza_alias_repetido(cliente):
    cliente.post("/acortar", data={"url": "https://a.com", "alias": "abc"})
    r = cliente.post("/acortar", data={"url": "https://b.com", "alias": "abc"}, follow_redirects=True)
    assert "ya está en uso" in r.get_data(as_text=True)


def test_eliminar(cliente):
    cliente.post("/acortar", data={"url": "https://a.com", "alias": "borrar"})
    cliente.post("/eliminar/borrar")
    assert cliente.get("/borrar").status_code == 404
